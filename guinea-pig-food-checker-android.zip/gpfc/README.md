# Can My Guinea Pig Eat This? Build guide

One web codebase, three outputs: an installable web app (PWA), an Android APK,
and a home-screen widget. Everything lives in `www/index.html`. Edit the food
list there and every output updates.

## What you need
- Node.js 18 or newer
- Android Studio (gives you the Android SDK and the build tools)
- A JDK 17 (Android Studio bundles one)

## Option A: Try it as a web app first (no tools, 1 minute)
1. Open `www/index.html` in any browser. Done.
2. To install it on a phone with no accounts: host the `www` folder on any
   static host (GitHub Pages is free), open the URL in Chrome on Android, then
   menu, "Add to Home screen". It runs full screen and works offline.

## Option B: Easiest APK (no coding)
1. Host the `www` folder (GitHub Pages or similar).
2. Go to pwabuilder.com, paste the URL, and download the Android package.
3. It produces a signed APK or AAB ready for the Play Store.
Note: this route does not include the custom widget.

## Option C: Full APK with the widget (recommended)
From inside this folder:

    npm install
    npx cap add android
    npx cap sync

Then add the widget (files are in `android-widget/`). The Android app package
is `nz.guineapig.foodchecker`, so paths below use that.

1. Copy `android-widget/java/GuineaPigWidget.kt` into
   `android/app/src/main/java/nz/guineapig/foodchecker/`
2. Copy the `res` files into `android/app/src/main/res/`, merging folders:
   - `layout/guinea_pig_widget.xml`
   - `xml/guinea_pig_widget_info.xml`
   - `drawable/widget_bg.xml`
3. Open `android/app/src/main/res/values/strings.xml` and add the `widget_desc`
   string from `android-widget/res/values/widget_strings.xml`.
4. Open `android/app/src/main/AndroidManifest.xml` and paste the `<receiver>`
   block from `android-widget/AndroidManifest-receiver-snippet.xml` inside the
   `<application>` element.
5. Optional: to make the keyboard pop up on launch, replace the generated
   `MainActivity.kt` with `android-widget/MainActivity-keyboard-optional.kt`.

Build and run:

    npx cap open android

In Android Studio, press Run for a debug APK, or Build, Generate Signed
Bundle / APK for a release build.

## Updating the food list later
Edit the `FOODS` array in `www/index.html`, then run `npx cap sync` and rebuild.
Each food entry is:

    {n:"name", a:["alias","alias"], s:"safe|limit|never",
     amt:"how much", freq:"how often", note:"why"}

## Honest notes
- The widget is a launcher tile. Android home-screen widgets cannot hold a live
  text box, so the tile opens the app with the search field already focused.
- iOS is not included. An iOS build needs a Mac with Xcode and an Apple
  Developer account. The same `www` folder will wrap with `npx cap add ios`
  whenever you have a Mac.
- This is a quick reference, not veterinary advice. For health concerns or
  foods not in the list, check with an exotic vet.
