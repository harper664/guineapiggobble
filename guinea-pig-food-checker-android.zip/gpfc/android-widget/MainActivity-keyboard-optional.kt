package nz.guineapig.foodchecker

import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.content.Context
import com.getcapacitor.BridgeActivity

// OPTIONAL. Replace the generated MainActivity with this version only if you
// want the soft keyboard to appear automatically on launch.
//
// WebView autofocus places the cursor in the box, but Android often waits for
// a user tap before showing the keyboard. This nudges it open.
class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridge?.webView?.postDelayed({
            bridge?.webView?.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(bridge?.webView, InputMethodManager.SHOW_IMPLICIT)
        }, 350)
    }
}
